﻿using System.ComponentModel.Design;
using System;
using System.Text.RegularExpressions;
class Program
{
    public static void Main(string[] args)
    {
        EntityMenu menu = new EntityMenu();
        menu.MenuLogic();
    }

}
